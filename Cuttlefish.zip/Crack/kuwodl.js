/*
Unlocks by Cuttlefish 公众号：墨鱼手记
*/
let url = $request.url.replace(/uid=\d+/g, "uid=2");
$done({url});